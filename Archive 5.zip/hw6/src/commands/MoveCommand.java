package commands;

/**
 * Placeholder move command.
 */
public class MoveCommand implements Runnable {

  /**
   * Placeholder move command.
   */
  @Override
  public void run() {
    //Placeholder
    System.out.println("move placeholder");
  }
}
