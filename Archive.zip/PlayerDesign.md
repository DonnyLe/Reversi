# Player Design

We want to be able to have a game played with either 2 players, a player and an
AI and 2 AIs.

We will have a player Interface, which can work with both a human and a computer. The Interface
will have to select the type of view used, GUI for a human and just fetching the board as data
for the computer. 
