package commands;

/**
 * Placeholder pass command.
 */
public class PassCommand implements Runnable {
  /**
   * Placeholder pass command.
   */
  @Override
  public void run() {
    //Placeholder
    System.out.println("pass placeholder");
  }
}
